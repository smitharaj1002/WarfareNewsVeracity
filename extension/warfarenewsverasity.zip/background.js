chrome.runtime.onInstalled.addListener(() => {
  console.log("Warfare News Veracity extension installed.");
});
