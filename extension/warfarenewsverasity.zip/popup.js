document.getElementById("checkBtn").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript(
      {
        target: { tabId: tabs[0].id },
        func: () => window.getSelection().toString()
      },
      (results) => {
        const text = results[0].result;
        const statusEl = document.getElementById("status");

        if (!text) {
          statusEl.innerText = "⚠️ Please highlight some text.";
          return;
        }

        statusEl.innerHTML = `<span class="loading">🔍 Checking...</span>`;

        // Step 1: Call /check endpoint
        fetch("http://127.0.0.1:5000/check", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text })
        })
          .then((res) => res.json())
          .then((checkData) => {
            // Step 2: Call /fact-check endpoint
            fetch("http://127.0.0.1:5000/fact-check", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ query: text })
            })
              .then((res) => res.json())
              .then((factData) => {
                let claimResults = "";
                if (factData.claims && factData.claims.length > 0) {
                  claimResults = `<ul>` + factData.claims.slice(0, 3).map(c =>
                    `<li>🗞️ <b>${c.reviewer || "Unknown"}</b>: ${c.text}</li>`
                  ).join("") + `</ul>`;
                } else {
                  claimResults = "⚠️ No relevant fact-checks found.";
                }

                statusEl.innerHTML = `
                  <b>🧠 NLP Verdict:</b> ${checkData.verdict} (${checkData.confidence})<br><br>
                  <b>🔍 Fact Check Results:</b><br>${claimResults}
                `;
              });
          })
          .catch(() => {
            statusEl.innerText = "❌ Error connecting to server.";
          });
      }
    );
  });
});
